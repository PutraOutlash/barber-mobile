import 'package:flutter/material.dart';

class BookingPage extends StatefulWidget {
  @override
  State<BookingPage> createState() => _BookingPageState();
}

class _BookingPageState extends State<BookingPage> {
  String selectedService = "";
  String selectedHair = "";
  String selectedTime = "";
  String selectedBarber = "";

  bool wash = false;
  bool styling = false;

  int basePrice = 0;

  int getTotal() {
    int total = basePrice;
    if (wash) total += 10000;
    if (styling) total += 15000;
    return total;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,

      appBar: AppBar(backgroundColor: Colors.black, title: Text("Booking")),

      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          // 🔥 LAYANAN
          Text("PILIH LAYANAN UTAMA", style: TextStyle(color: Colors.white)),

          SizedBox(height: 10),

          serviceCard(title: "Haircut", price: 25000),

          serviceCard(title: "Hair Coloring", price: 50000),

          SizedBox(height: 20),

          // 🔥 JADWAL
          Text("JADWAL & JAM", style: TextStyle(color: Colors.white)),

          SizedBox(height: 10),

          Wrap(
            spacing: 10,
            children: [
              "10:00",
              "11:00",
              "13:00",
              "14:00",
            ].map((t) => timeBtn(t)).toList(),
          ),

          SizedBox(height: 20),

          // 🔥 JENIS POTONGAN
          Text("JENIS POTONGAN", style: TextStyle(color: Colors.white)),

          SizedBox(height: 10),

          Row(
            children: [
              hairCard("Classic Fade"),
              SizedBox(width: 10),
              hairCard("Pompadour"),
            ],
          ),

          SizedBox(height: 20),

          // 🔥 RINGKASAN
          Container(
            padding: EdgeInsets.all(16),
            decoration: box(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("RINGKASAN PESANAN", style: TextStyle(color: Colors.grey)),

                SizedBox(height: 10),

                item("Layanan", selectedService),
                item("Gaya", selectedHair),
                item("Waktu", selectedTime),
                item("Barber", selectedBarber),

                SizedBox(height: 10),

                Text("TOTAL", style: TextStyle(color: Colors.grey)),

                Text(
                  "Rp ${getTotal()}",
                  style: TextStyle(
                    color: Colors.amber,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                SizedBox(height: 10),

                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.amber,
                  ),
                  onPressed: () {
                    // 🔥 QRIS
                    showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: Text("Scan QRIS"),
                        content: Image.network(
                          "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=PAYMENT",
                        ),
                      ),
                    );
                  },
                  child: Text(
                    "BAYAR SEKARANG",
                    style: TextStyle(color: Colors.black),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // 🔥 SERVICE CARD (expandable)
  Widget serviceCard({required String title, required int price}) {
    bool selected = selectedService == title;

    return GestureDetector(
      onTap: () {
        setState(() {
          selectedService = title;
          basePrice = price;
        });
      },
      child: Container(
        margin: EdgeInsets.only(bottom: 10),
        padding: EdgeInsets.all(16),
        decoration: box(border: selected),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: TextStyle(color: Colors.white)),

            Text("Rp $price", style: TextStyle(color: Colors.amber)),

            if (selected) ...[
              SizedBox(height: 10),

              // 🔥 ADD ON
              CheckboxListTile(
                value: wash,
                onChanged: (v) => setState(() => wash = v!),
                title: Text(
                  "Keramas +10k",
                  style: TextStyle(color: Colors.white),
                ),
              ),

              CheckboxListTile(
                value: styling,
                onChanged: (v) => setState(() => styling = v!),
                title: Text(
                  "Styling +15k",
                  style: TextStyle(color: Colors.white),
                ),
              ),

              // 🔥 BARBER
              DropdownButton<String>(
                dropdownColor: Colors.black,
                hint: Text(
                  "Pilih Barber",
                  style: TextStyle(color: Colors.white),
                ),
                value: selectedBarber.isEmpty ? null : selectedBarber,
                items: ["Andi", "Budi"]
                    .map(
                      (e) => DropdownMenuItem(
                        value: e,
                        child: Text(e, style: TextStyle(color: Colors.white)),
                      ),
                    )
                    .toList(),
                onChanged: (v) => setState(() => selectedBarber = v!),
              ),
            ],
          ],
        ),
      ),
    );
  }

  // 🔥 TIME
  Widget timeBtn(String t) {
    bool selected = selectedTime == t;

    return GestureDetector(
      onTap: () => setState(() => selectedTime = t),
      child: Container(
        padding: EdgeInsets.all(12),
        decoration: box(border: selected),
        child: Text(t, style: TextStyle(color: Colors.white)),
      ),
    );
  }

  // 🔥 HAIR STYLE
  Widget hairCard(String name) {
    bool selected = selectedHair == name;

    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => selectedHair = name),
        child: Container(
          height: 120,
          decoration: box(border: selected),
          child: Center(
            child: Text(name, style: TextStyle(color: Colors.white)),
          ),
        ),
      ),
    );
  }

  Widget item(String title, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(title, style: TextStyle(color: Colors.grey)),
        Text(value, style: TextStyle(color: Colors.white)),
      ],
    );
  }

  BoxDecoration box({bool border = false}) {
    return BoxDecoration(
      color: Color(0xFF1C1C1C),
      borderRadius: BorderRadius.circular(12),
      border: border ? Border.all(color: Colors.amber) : null,
    );
  }
}
