import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api.dart';

class AuthService {
  static Future<Map<String, dynamic>> login(
    String email,
    String password,
  ) async {
    var res = await http.post(
      Uri.parse("${Api.baseUrl}/login.php"),
      headers: {"Content-Type": "application/x-www-form-urlencoded"},
      body: {"email": email, "password": password},
    );

    print("STATUS: ${res.statusCode}");
    print("RESPONSE: ${res.body}");

    return jsonDecode(res.body);
  }
}
