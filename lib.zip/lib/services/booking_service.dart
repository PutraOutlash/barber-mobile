import 'dart:convert';
import 'package:http/http.dart' as http;
import 'api.dart';

class BookingService {
  // 🔥 GET SERVICES
  static Future<List> getServices() async {
    var res = await http.get(Uri.parse("${Api.baseUrl}/service/get.php"));
    return jsonDecode(res.body);
  }

  // 🔥 GET BARBERS
  static Future<List> getBarbers() async {
    var res = await http.get(Uri.parse("${Api.baseUrl}/booking/barbers.php"));
    return jsonDecode(res.body);
  }

  // 🔥 GET SLOT
  static Future<List> getSlots(String date, int barberId, int duration) async {
    var res = await http.get(
      Uri.parse(
        "${Api.baseUrl}/booking/slots.php?date=$date&barber_id=$barberId&duration=$duration",
      ),
    );
    return jsonDecode(res.body);
  }

  // 🔥 SAVE BOOKING
  static Future saveBooking(Map data) async {
    var res = await http.post(
      Uri.parse("${Api.baseUrl}/booking/create.php"),
      body: data,
    );

    return jsonDecode(res.body);
  }

  // 🔥 HISTORY
  static Future<List> getHistory(int userId) async {
    var res = await http.get(
      Uri.parse("${Api.baseUrl}/booking/get.php?user_id=$userId"),
    );
    return jsonDecode(res.body);
  }
}
